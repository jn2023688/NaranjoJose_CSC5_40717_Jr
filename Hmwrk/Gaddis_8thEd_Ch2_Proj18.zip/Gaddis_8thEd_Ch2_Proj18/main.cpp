/* 
 * File:   main.cpp
 * Author: Jose Naranjo
 *
 * Created on January 8, 2015, 8:18 AM
 */

#include <iostream>

using namespace std;
//user Libraries


//Global Constants
const char CONVPCT=100; //Percent conversion

//Execution Begins here
int main(int argc, char** argv) {
//Declare Variables
    short custSrv=16500;
    char perEDrk=15;
    char perCDrk=58;
    //calculate customer numbers requested 
    short custE=custSrv*perEDrk/CONVPCT;//Energy Drink
    short custC=custE*perCDrk/CONVPCT;//Citrus Drink
    //Output the results
    cout<<"Customers surveyed that are energy drinkers=";
    cout<<custE<<endl;
    cout<<"Customers surveyed that are citrus drinkers=";
    cout<<custC<<endl;
    return 0;
}

